<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wodospady</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h2>Łowcy wodospadów</h2>
    </header>
    <main>
        <div class="blokBoczny">
            <?php
                $db = mysqli_connect('localhost', 'root', '', 'wodospady');
                $zapytanie1 = "SELECT idKontynent, nazwa FROM kontynenty";
                $wynik = mysqli_query($db, $zapytanie1);
                while ($wiersz = mysqli_fetch_assoc($wynik)){
                    echo '<a href="index.php?id=' . $wiersz['idKontynent'] . '">'. $wiersz     ['nazwa']. "</a>";
                }
                mysqli_close($db);
            ?>
        </div>
        <div class="blokSekcji">
            <table>
                <thead>
                    <tr>
                        <th>Indentyfikator</th>
                        <th>Państwo</th>
                        <th>Nazwa wodospadu</th>
                        <th>Wysokość</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $id = isset($_GET['id']) ? $_GET['id'] : 6;
                    $db = mysqli_connect('localhost', 'root', '', 'wodospady');
                    $zapytanie2 = "SELECT idObiekt, panstwo, nazwa, wartoscCechy FROM obiekty WHERE idRodzaj = 10 AND idKontynent = $id";
                    $wynik = mysqli_query($db, $zapytanie2);
                    while ($wiersz = mysqli_fetch_assoc($wynik)){
                        echo "<tr>";
                        echo "<td>" . $wiersz['idObiekt'] . "</td>";
                        echo "<td>" . $wiersz['panstwo'] . "</td>";
                        echo "<td>" . $wiersz['nazwa'] . "</td>";
                        echo "<td>" . $wiersz['wartoscCechy'] . "</td>";
                        echo "</tr>";
                    }
                    mysqli_close($db);
                    ?>
                </tbody>
            </table>
            <h4>Wpisz osiągnięcie do bazy</h4>
            <label for="identyfikator">identyfikator wodospadu</label>
            <input type="number" id="identyfikator">
            <label for="turysta">turysta</label>
            <select name="turysta" id="turysta">
                <?php
                    $db = mysqli_connect('localhost', 'root', '', 'wodospady');
                    $zapytanie3 = "SELECT idTurysta, nick FROM turysci";
                    $wynik = mysqli_query($db, $zapytanie3);
                    while ($wiersz = mysqli_fetch_assoc($wynik)){
                        echo '<option value="' . $wiersz['idTurysty'] . '">' . $wiersz['nick'] . '</option>'; 
                    }
                    mysqli_close($db);
                    ?>
            </select>
                <button type="submit">wyślij</button>
                <?php
                    // $db = mysqli_connect('localhost', 'root', '', 'wodospady');
                    // $zapytanie4 = "INSERT INTO osiagniecia (idObiekt, idTurysta) VALUES (34, 2);";
                    // $wynik = mysqli_query($db, $zapytanie4);
                    // while ($wiersz = mysqli_fetch_assoc($wynik)){
                        
                    // }
                    // mysqli_close($db);
                ?>
        </div>
    </main>
    <aside>
        <h3>Wodospady w Polsce</h3>
        <img src="kamienczyk.jpg" alt="kamienczyk">
        <img src="siklawica.jpg" alt="siklawica" id="siklawica">
        <img src="siklawa.jpg" alt="siklawa">
        <img src="wilczki.jpg" alt=""wilczki>
    </aside>
    <footer>
        <p>Autor: Jakub Bożym</p>
    </footer>
</body>
</html>